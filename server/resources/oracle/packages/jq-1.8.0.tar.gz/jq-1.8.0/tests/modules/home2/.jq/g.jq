def g: 1;
