#define PGPOOLVERSION "chirikoboshi"

