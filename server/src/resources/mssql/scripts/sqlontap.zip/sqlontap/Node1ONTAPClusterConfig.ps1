[CmdletBinding()]
param(

    [Parameter(Mandatory=$true)]
    [string]$DomainDnsName,

    [Parameter(Mandatory=$true)]
    [string]$WSFCNode1PrivateIP2,

    [Parameter(Mandatory=$true)]
    [string]$ClusterName,

    [Parameter(Mandatory=$true)]
    [string]$AdminSecret,

    [Parameter(Mandatory=$true)]
    [string]$DomainAdminUser

)
#Requires -Modules xFailOverCluster,PSDscResources,xActiveDirectory
try {
Start-Transcript -Path C:\cfn\log\node1ONTAPClusterConfig.ps1.txt -Append
$ErrorActionPreference = "Stop"
# Getting the DSC Cert Encryption Thumbprint to Secure the MOF File
$DscCertThumbprint = (get-childitem -path cert:\LocalMachine\My | where { $_.subject -eq "CN=AWSLWDscEncryptCert" }).Thumbprint
# Getting Password from Secrets Manager for AD Admin User
$DomainNetBIOSName = $env:USERDOMAIN
$AdminUser = ConvertFrom-Json -InputObject (Get-SECSecretValue -SecretId $AdminSecret).SecretString
$ClusterAdminUser = $DomainNetBIOSName + '\' + $DomainAdminUser
# Creating Credential Object for Administrator
$Credentials = (New-Object PSCredential($ClusterAdminUser,(ConvertTo-SecureString $AdminUser.Password -AsPlainText -Force)))
$disklist=Get-Disk | Where-Object{$_.FriendlyName -eq 'NETAPP LUN C-MODE'} | Sort-Object -Property Size

$ConfigurationData = @{
    AllNodes = @(
        @{
            NodeName="*"
            CertificateFile = "C:\cfn\dsc\publickeys\AWSLWDscPublicKey.cer"
            Thumbprint = $DscCertThumbprint
            PSDscAllowDomainUser = $true
        },
        @{
            NodeName = 'localhost'
        }
    )
}

Configuration Node1ClusterConfig {
    param(
        [PSCredential] $Credentials
    )

    Import-Module -Name PSDscResources
    Import-Module -Name xFailOverCluster
    Import-Module -Name xActiveDirectory

    Import-DscResource -Module PSDscResources
    Import-DscResource -ModuleName xFailOverCluster
    Import-DscResource -ModuleName xActiveDirectory

    Node 'localhost' {

        WindowsFeature AddRemoteServerAdministrationToolsClusteringFeature {
            Ensure    = 'Present'
            Name      = 'RSAT-Clustering-Mgmt'
        }

        WindowsFeature AddRemoteServerAdministrationToolsClusteringPowerShellFeature {
            Ensure    = 'Present'
            Name      = 'RSAT-Clustering-PowerShell'
            DependsOn = '[WindowsFeature]AddRemoteServerAdministrationToolsClusteringFeature'
        }

        WindowsFeature AddRemoteServerAdministrationToolsClusteringCmdInterfaceFeature {
            Ensure    = 'Present'
            Name      = 'RSAT-Clustering-CmdInterface'
            DependsOn = '[WindowsFeature]AddRemoteServerAdministrationToolsClusteringPowerShellFeature'
        }

        xCluster CreateCluster {
            Name                          =  $ClusterName
            StaticIPAddress               =  $WSFCNode1PrivateIP2
            DomainAdministratorCredential =  $Credentials
            DependsOn                     = '[WindowsFeature]AddRemoteServerAdministrationToolsClusteringCmdInterfaceFeature'
        }

        xClusterDisk AddDataClusterDisk
        {
            Number = 1
            Ensure = 'Present'
            Label  = 'SQL-DATA'
        }

        xClusterDisk AddLogClusterDisk
        {
            Number = 2
            Ensure = 'Present'
            Label  = 'SQL-LOG'
        }

        xClusterDisk AddTempDbClusterDisk
        {
            Number = 3
            Ensure = 'Present'
            Label  = 'SQL-TEMPDB'
        }

        xClusterDisk AddQuorumClusterDisk
        {
            Number = 4
            Ensure = 'Present'
            Label  = 'Quorum'
        }

        xClusterQuorum SetQuorumToNodeMajority {
            IsSingleInstance = 'Yes'
            Type             = 'NodeAndDiskMajority'
            Resource         =  'Quorum'
            DependsOn        = '[xClusterDisk]AddQuorumClusterDisk'
            }
    }
    }
Node1ClusterConfig -OutputPath 'C:\cfn\dsc\Node1ClusterConfig' -ConfigurationData $ConfigurationData -Credentials $Credentials

Start-DscConfiguration 'C:\cfn\dsc\Node1ClusterConfig' -Wait -Verbose -Force

} catch{
    $_ | Write-AWSLaunchWizardException
}
