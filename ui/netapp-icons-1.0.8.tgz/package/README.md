# Icons library for NetApp BlueXP platform design system
According to the design system: https://www.figma.com/file/vNPUEtCuR4Enwhz1ZeTdQE/%F0%9F%92%8E-BlueXP(L%26D)-%2F-components

## Install
install the library in your service by simply running the following steps:
1. Create a file named .npmrc next to your package.json, the file should contain the following code
```bash
@netapp:registry=http://10.68.224.29:4873/
```
2. Run the following command
```bash
// Using npm
npm install @netapp/icons

// Using yarn
yarn add @netapp/icons
```

## Usage example
```jsx
import React, { Component } from 'react'

import { ReactComponent as ChatIcon } from '@netapp/icons/ic_chat.svg'

const Example = ()=>(
<>
<ChatIcon />
</>)
```
>You may find all available components and documentation at http://netapp-design-system.s3-website.eu-west-3.amazonaws.com/
