# UI components library for NetApp platform design system
According to the design system: https://www.figma.com/file/m2qHY6i3DnJfgbvZmn2ESx/BlueXP-Design-System

## Install
install the library in your service by simply running the following steps:
1. Create a file named .npmrc next to your package.json, the file should contain the following code
```bash
@netapp:registry=http://10.68.224.29:4873/
```
2. Run the following command
```bash
// Using npm
npm install @netapp/design-system

// Using yarn
yarn add @netapp/design-system
```

## Usage example
```jsx
import React, { Component } from 'react'

import { Notification } from '@netapp/design-system'

const Example = ()=>(
<>
<Notification />
</>)
```
>You may find all available components and documentation at http://netapp-design-system.s3-website.eu-west-3.amazonaws.com/
